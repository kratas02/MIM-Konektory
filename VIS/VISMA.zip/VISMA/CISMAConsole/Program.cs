﻿using FimSync_Ezma;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace CISMAConsole
{
    internal class Program
    {
        private const string User = "idm";
        private const string Pass = "249e1ceadda4ff460cda21a01c96203737b4fbb58fdc9ae9202b8c4f0876948aacd20a8eaa95c6735f10e0da778f6ab9ad9bfb2718b27421e1f5a0e273891e38cf2ff270238be2370f53122c106221c1895a751d3cd3c1d38c869132184c565812720763da5109f2362a110b99c2805395abc408c86eefa43e312605bd185c83";

        static async Task Main(string[] args)
        {
            var uri1 = "http://crow.asol.local:5003/api/v1/Custom/Idm/Users";
            IdmUser[] users1 = await GetUsersAsync(uri1, User, Pass);
            Console.WriteLine($"Test: {users1.Length} uživatelů");
            foreach (var user in users1)
                VypisUzivatele(user);
        }


        static void VypisUzivatele(IdmUser user)
        {
            foreach (var prop in typeof(IdmUser).GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if (prop.Name == nameof(IdmUser.ExtensionData))
                {
                    if (user.ExtensionData?.Count > 0)
                    {
                        Console.WriteLine($"  {prop.Name}:");
                        foreach (var kv in user.ExtensionData)
                            Console.WriteLine($"    {kv.Key} = {kv.Value}");
                    }
                    continue;
                }
                var value = prop.GetValue(user);
                Console.WriteLine($"  {prop.Name}: {value ?? "(null)"}");
            }
            Console.WriteLine();
        }

        static async Task<IdmUser[]> GetUsersAsync(string uri, string user, string pass)
        {
            var client = new HttpClient();
            var credentials = Convert.ToBase64String(
                Encoding.ASCII.GetBytes($"{user}:{pass}"));
            client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Basic", credentials);

            var response = await client.GetAsync(uri);
            response.EnsureSuccessStatusCode();

            var json = await response.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
            var users = JsonSerializer.Deserialize<IdmUser[]>(json, options);
            return users ?? Array.Empty<IdmUser>();
        }

    }
}