﻿
using Microsoft.MetadirectoryServices;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics.Contracts;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using static System.Net.Mime.MediaTypeNames;

namespace FimSync_Ezma
{
    public class EzmaExtension :
    //IMAExtensible2CallExport,
    IMAExtensible2CallImport,
    //IMAExtensible2FileImport,
    //IMAExtensible2FileExport,
    //IMAExtensible2GetHierarchy,
    IMAExtensible2GetSchema,
    IMAExtensible2GetCapabilities,
    IMAExtensible2GetParameters
    //IMAExtensible2GetPartitions
    {
        //
        // Constructor
        //
        public EzmaExtension()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        /// <summary>
        /// Implementace IMAExtensible2GetCapabilities
        /// Možnosti MA pro konfiguračního průvodce
        /// </summary>
        public MACapabilities Capabilities
        {
            get
            {
                MACapabilities myCapabilites = new MACapabilities
                {
                    ConcurrentOperation = true,
                    DeleteAddAsReplace = false,
                    DeltaImport = false,
                    DistinguishedNameStyle = MADistinguishedNameStyle.None,
                    ExportPasswordInFirstPass = false,
                    ExportType = MAExportType.AttributeUpdate,
                    FullExport = true,
                    NoReferenceValuesInFirstExport = false,
                    IsDNAsAnchor = false,
                    Normalizations = MANormalizations.None,
                    ObjectConfirmation = MAObjectConfirmation.NoAddAndDeleteConfirmation,
                    ObjectRename = false,
                    SupportExport = false,
                    SupportHierarchy = false,
                    SupportImport = true,
                    SupportPartitions = false,
                    SupportPassword = false
                };
                return myCapabilites;
            }
        }

        /// <summary>
        /// Implementace IMAExtensible2GetParameters
        /// Konfigurovatelné parametry MA pro průvodce
        /// </summary>
        /// <param name="configParameters"></param>
        /// <param name="page"></param>
        /// <returns></returns>
        public System.Collections.Generic.IList<ConfigParameterDefinition> GetConfigParameters(System.Collections.ObjectModel.KeyedCollection<string, ConfigParameter> configParameters, ConfigParameterPage page)
        {
            List<ConfigParameterDefinition> configParametersDefinitions = new List<ConfigParameterDefinition>();

            switch (page)
            {
                case ConfigParameterPage.Connectivity:

                    configParametersDefinitions.Add(ConfigParameterDefinition.CreateStringParameter("UserName", ""));
                    configParametersDefinitions.Add(ConfigParameterDefinition.CreateStringParameter("Password", ""));
                    configParametersDefinitions.Add(ConfigParameterDefinition.CreateStringParameter("URL", ""));
                    configParametersDefinitions.Add(ConfigParameterDefinition.CreateStringParameter("Log folder", ""));
                    break;

                case ConfigParameterPage.Global:
                    //configParametersDefinitions.Add(ConfigParameterDefinition.CreateStringParameter("Kód organizace", ""));
                    //configParametersDefinitions.Add(ConfigParameterDefinition.CreateCheckBoxParameter("Před importem spustit výpočet v SAP"));
                    break;

                case ConfigParameterPage.Partition:
                    break;

                case ConfigParameterPage.RunStep:

                    break;
            }

            return configParametersDefinitions;

        }

        /// <summary>
        /// Implementace IMAExtensible2GetParameters
        /// Validace parametrů, nevyužito
        /// </summary>
        /// <param name="configParameters"></param>
        /// <param name="page"></param>
        /// <returns></returns>
        public ParameterValidationResult ValidateConfigParameters(System.Collections.ObjectModel.KeyedCollection<string, ConfigParameter> configParameters, ConfigParameterPage page)
        {
            ParameterValidationResult myResults = new ParameterValidationResult();

            return myResults;
        }

        /// <summary>
        /// Implementace IMAExtensible2GetSchema
        /// Datové schéma ConnectorSpace
        /// </summary>
        /// <param name="configParameters"></param>
        /// <returns></returns>
        public Schema GetSchema(System.Collections.ObjectModel.KeyedCollection<string, ConfigParameter> configParameters)
        {

            Microsoft.MetadirectoryServices.SchemaType personType = Microsoft.MetadirectoryServices.SchemaType.Create("Person", false);
            personType.Attributes.Add(SchemaAttribute.CreateAnchorAttribute("employeeId", AttributeType.String));

            foreach (var prop in typeof(IdmUser).GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if (prop.Name.ToLower() != "employeeid")
                    personType.Attributes.Add(SchemaAttribute.CreateSingleValuedAttribute(prop.Name, AttributeType.String));
            }


            Schema schema = Schema.Create();
            schema.Types.Add(personType);

            return schema;

        }

        public void Log(string text)
        {
            File.AppendAllText(logFile, $"[{DateTime.Now.ToString("HH:mm")}] {text}{Environment.NewLine}");
            //File.AppendAllText("C:\\IDM\\Log\\VISMA\\log.txt", text + Environment.NewLine);
        }

        int importCount = 0;
        int importCountContracts = 0;
        int pageSize = 100;
        string logFile = null;
        IdmUser[] users = null;
        /// <summary>
        /// Spuštění importu. Je zavolána webová služba a stažena data.
        /// Data uložena do privátní proměnné pro další zpracování.
        /// </summary>
        /// <param name="configParameters"></param>
        /// <param name="types"></param>
        /// <param name="importRunStep"></param>
        /// <returns></returns>
        public OpenImportConnectionResults OpenImportConnection(System.Collections.ObjectModel.KeyedCollection<string, ConfigParameter> configParameters, Schema types, OpenImportConnectionRunStep importRunStep)
        {

            string username = configParameters["UserName"].Value;
            string pass = "249e1ceadda4ff460cda21a01c96203737b4fbb58fdc9ae9202b8c4f0876948aacd20a8eaa95c6735f10e0da778f6ab9ad9bfb2718b27421e1f5a0e273891e38cf2ff270238be2370f53122c106221c1895a751d3cd3c1d38c869132184c565812720763da5109f2362a110b99c2805395abc408c86eefa43e312605bd185c83";
            //configParameters["Password"].Value;
            string uri = configParameters["URL"].Value;
            logFile = Path.Combine(configParameters["Log folder"].Value, "VIS" + DateTime.Now.ToString("yyyyMMdd") + ".txt");
            Log(username);
            Log(uri);
            users = GetUsers(uri, username, pass);
            Log($"Nacteno {users.Length} objektu");
            //pageSize = importRunStep.PageSize;
            return new OpenImportConnectionResults();
        }

        /// <summary>
        /// Zpracování záznamů. Pracuje po "stránkách", musí. Maximální počet záznamů,
        /// které může tato metoda zpracovat v jednom běhu je 9999. Pokud není import
        /// dokončen, je nastaveno výstupní info MoreToImport=True
        /// </summary>
        /// <param name="importRunStep"></param>
        /// <returns></returns>
        public GetImportEntriesResults GetImportEntries(GetImportEntriesRunStep importRunStep)
        {
            int firstRecord = importCount * pageSize;
            int lastRecord = importCount * pageSize + pageSize - 1;

            List<CSEntryChange> csentries = new List<CSEntryChange>();
            Log($"first:{firstRecord} - last:{lastRecord}");

            for (int i = firstRecord; i <= lastRecord; i++)
            {

                CSEntryChange csentry = CSEntryChange.Create();
                csentry.ObjectModificationType = ObjectModificationType.Add;
                csentry.ObjectType = "Person";
                foreach (var prop in typeof(IdmUser).GetProperties(BindingFlags.Public | BindingFlags.Instance))
                {
                    var user = users[i];
                    var value = prop.GetValue(user);
                    if (value != null)
                        csentry.AttributeChanges.Add(AttributeChange.CreateAttributeAdd(prop.Name, user));
                }
                csentries.Add(csentry);
            }
            importCount += 1;


            GetImportEntriesResults importReturnInfo = new GetImportEntriesResults();
            Log($"{users.Length} - {lastRecord}");

            if (users.Length - 1 > lastRecord)
                importReturnInfo.MoreToImport = true;
            else
                importReturnInfo.MoreToImport = false;

            //importReturnInfo.MoreToImport = true;

            return importReturnInfo;

        }
        /// <summary>
        /// Ukončení importu, nevyužito
        /// </summary>
        /// <param name="importRunStep"></param>
        /// <returns></returns>
        public CloseImportConnectionResults CloseImportConnection(CloseImportConnectionRunStep importRunStep)
        {
            return new CloseImportConnectionResults();
        }

        static IdmUser[] GetUsers(string uri, string user, string pass)
        {
            try
            {

                var client = new HttpClient();
                var credentials = Convert.ToBase64String(
                    Encoding.ASCII.GetBytes($"{user}:{pass}"));
                client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Basic", credentials);

                var response = client.GetAsync(uri).GetAwaiter().GetResult();
                response.EnsureSuccessStatusCode();

                var json = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                var users = JsonSerializer.Deserialize<IdmUser[]>(json, options);
                return users ?? Array.Empty<IdmUser>();
            }
            catch (Exception e)
            {
                File.AppendAllText("C:\\IDM\\Log\\VISMA\\log.txt", e.Message + Environment.NewLine);
                File.AppendAllText("C:\\IDM\\Log\\VISMA\\log.txt", e.StackTrace + Environment.NewLine);
                return Array.Empty<IdmUser>();
            }
        }

        /// <summary>
        /// Výchozí velikost stránky pro průvodce Sync Run
        /// </summary>
        public int ImportDefaultPageSize
        {
            get { return 1000; }
        }

        /// <summary>
        /// Maximální povolená velikost stránky
        /// </summary>
        public int ImportMaxPageSize
        {
            get { return 1000; }
        }

    };
}
